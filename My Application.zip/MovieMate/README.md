# MovieMate
App which shows movie and TV shows rating.
